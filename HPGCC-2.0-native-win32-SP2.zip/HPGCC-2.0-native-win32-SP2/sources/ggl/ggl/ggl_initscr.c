#include <hpgcc49.h>

#include "gglpr.h"


int __gglorgaddr;

void ggl_initscr(gglsurface *srf)
{
__gglorgaddr=(int)sys_phys_malloc( (BUFSIZE<<1) + 16);
srf->addr=(int *) ((sys_map_v2p(__gglorgaddr)+15)&0xfffffff0);
srf->width=LCD_W;
srf->x=srf->y=0;
}

void ggl_freescr()
{
    free(__gglorgaddr);
}
