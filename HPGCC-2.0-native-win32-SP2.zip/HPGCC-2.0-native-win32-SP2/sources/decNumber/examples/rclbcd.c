//@<head>

#define  DECNUMDIGITS 32           // work with up to 32 digits
#include "decNumber.h"             // base number library

#include <hpgcc49.h>
//#include <hpstack.h>


#ifndef MUL10
#define MUL10(x) (10*(x))
//#define MUL10(x) (((x) << 1) + ((x) << 3))
#endif


// $Head: $

//@</head>


//@<func name="bcd_get_coefficient">

void
bcd_get_coefficient(unsigned addr, int n_digits, decNumber *dn)
{
    unsigned i,p;
    
    i = 0;
    dn->digits = n_digits;
    p = addr-1;
    
    while (n_digits > 0) {
    
        int j,cnt,step;
        decNumberUnit unit;
        
        cnt = step = min(DECDPUN,n_digits);
        p += step;
        unit = 0;
        
        for (j = p; cnt ; j--,cnt--)
            unit = MUL10(unit) + sat_peek(j,1);
        
        dn->lsu[i++] = unit;
        
        n_digits -= step;
        
    }
        
    
    if (dn->digits <= 0)
        dn->digits=1;
    
}
    
//@</func>

//@<func name="bcd_alloc_number">

decNumber
*bcd_alloc_number(int digits)
{
    decNumber *p;
    
    sys_chkptr(p = (decNumber *)calloc(1,(digits+DECDPUN-1)/DECDPUN*sizeof(decNumberUnit) + 2*sizeof(int32_t) + sizeof(uint8_t)));
    p->digits = digits;
    
    return p;
}

//@</func>


//@<func name="sat_bcd2decNumber">

int
sat_bcd2decNumber(unsigned addr, decNumber **dn)
{
    
    int prolog = sat_peek(addr,5);
    
    addr += 5;
    
    if (REAL_0 <= prolog && prolog <= REAL_9) {
        *dn = bcd_alloc_number(1);
        (*dn)->lsu[0] = (decNumberUnit)(prolog - REAL_0)/21;
    
    }
    
    else if (prolog == SAT_DOREAL) {
        *dn = bcd_alloc_number(12);
        int expo = (int) sat_BCD2LONGLONG(addr,3);
        if (expo > 499)
            expo -= 1000;
        (*dn)->exponent = expo-11;
        bcd_get_coefficient(addr+3,12,*dn);
        if ((int) sat_BCD2LONGLONG(addr+15,1) == 9)
            (*dn)->bits |= DECNEG;
        
    }
    else return -1; // ERROR
        
    return 0;
}
    
//@</func>

//@<func name="sat_rcl_bcd">    
int
sat_rcl_bcd(char *name,decNumber **num)
{
    
    SAT_OBJ_DSCR *dirobj;
    
    if ((dirobj = sat_dir_rclobject(name))) 
        return sat_bcd2decNumber(dirobj->addr,num);
        
    
    return -1;
}

//@</func>

//@<func name="sat_pick_bcd">

int 
sat_pick_bcd (int level, decNumber **val)
{
    
    SAT_STACK_ELEMENT e;
    
    if (sat_get_stack_element(level,&e))
        return -1;
    
    if (e.prologue == SAT_DOREAL || (REAL_0 <= e.prologue && e.prologue <= REAL_9)) {
        sat_bcd2decNumber(e.addr,val);
        return 0;
    }
    
    return -2;
}
        
//@</func>

//@<func name="sat_pop_bcd">    
int
sat_pop_bcd(decNumber **num)
{
    int r = 0;
    
    if (!(r = sat_pick_bcd(1,num)))
        sat_stack_drop();
        
    
    return r;
}

//@</func>

//@<func name="sat_pick_str">    

char
*sat_pick_str(int level,char *buf)
{
    
    SAT_STACK_ELEMENT e; 
    
    if(sat_get_stack_element(level,&e) || e.prologue != SAT_DOCSTR)
        return NULL;
    

    int stringChars = (sat_peek_sat_addr(e.addr+5) - 5) / 2; //number of chars in the string
    
    sat_peek_sat_bytes(buf,e.addr+10,stringChars); //copy the string into our buffer
    buf[stringChars]='\0'; //tack on a null terminator
    
    
    return buf;
}
    
//@</func>

//@<func name="sat_pop_str">    

char
*sat_pop_str(char *buf)
{
    char *s;
    
    if ((s = sat_pick_str(1,buf))) 
        sat_stack_drop();
    
    return s;
}
    
//@</func>

//@<func name="bcd_set_maxdigits">

int __bcd_maxdigits = DECNUMDIGITS;

int
bcd_set_maxdigits(int dig)
{
    int old = __bcd_maxdigits;
    
    if (dig > 0)
        __bcd_maxdigits = dig;
    
    return old;
}

//@</func>

//@<func name="bcd_zerotrim_str">
char
*bcd_zerotrim_str(char *s)
{
    char *p = (char *)((unsigned long) s + strlen(s) - 1);
    
    while (p > s) 
        if (*p == '0')
            *p-- = '\0';
        else
            break;
    
    
    return s;
}

//@</func>


int main() {
 
  decContext set;                  // working context
  char string[DECNUMDIGITS+14];    // conversion buffer
  decNumber *num;

  unsigned stack = sat_stack_init();
  

  decContextDefault(&set, DEC_INIT_BASE); // initialize
  set.traps=0;                      // no traps, thank you
  set.digits=DECNUMDIGITS;            // set precision

  char varName[64];
    
  if (sat_pop_str(varName) && !sat_rcl_bcd(varName,&num)) {
      
      decNumber *e,z;
      
      if (! sat_pop_bcd(&e)) {
            decNumberMultiply(&z,e,num,&set);
            decNumberToString(&z,string);
      }
      else
        decNumberToString(num,string);
      
      sat_stack_push_string(bcd_zerotrim_str(string));
      
      decNumber two;
      decNumberFromString(&two,"2",&set);
      
      set.digits = 128;
      char sqrt_str[set.digits+14];
      decNumber *res = bcd_alloc_number(set.digits);
      decNumberSquareRoot(res,&two,&set);
      decNumberToString(res,sqrt_str);
      sat_stack_push_string(sqrt_str);
      
      
  }
  else {
      
      sat_stack_push_string("Boo...");
      //beep();
  }
 
  sat_stack_exit(stack);
  
  return 0;

} 
