// GENERAL GLOBAL VARIABLES SETUP

#include <hpgcc_config.h>

unsigned int _saturn_cpu;
unsigned int _ram_base_addr,_code_base_addr,_ram_size,_heap_base_addr,_mmu_table_addr,_mmu_table_entries;

// Adds a version magic to the globals section, which elf2hp can scan for
// < ibl ; 2005-12-02>

unsigned int __elf2hp_version_info = (HPGCC_VERSION_MAJOR << 16) | HPGCC_VERSION_MINOR;

void _init_globals(int sat_cpu,int rsize,int cbase,int hbase,int nentries)
{
    // Purpose is to avoid the relocation bug of ld 
   
    char bug[] __attribute__((unused)) = "BUG";

_saturn_cpu=sat_cpu;
_ram_base_addr=0x01101000;
_ram_size=rsize;
_heap_base_addr=hbase;
_code_base_addr=cbase;
_mmu_table_addr=0x01100000;
_mmu_table_entries=nentries;
}
