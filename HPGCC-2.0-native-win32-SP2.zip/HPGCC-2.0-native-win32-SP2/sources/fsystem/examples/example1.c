//@<head>
//& <prolog>
//& ****************************************************************************
//&
//& Written by Claudio Lapilli, February 2006
//&
//& Copyright (C) 2006 HP-GCC Development Team
//&
//& ****************************************************************************
//&
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//&
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************

//& </prolog>

// $Header: example1.c,r42 2006-02-18 04:23:47 ingo $


// VOLUME MANAGEMENT FUNCTIONS EXAMPLE

#include <hpgcc49.h>

#include <fsystem.h>


int main()
{
int error;
int f;


clear_screen();

// SHOW INFORMATION ABOUT MOUNTED VOLUMES
for(f=0;f<4;++f)
{
error=FSVolumeInserted(f);
if(error==FS_OK)
 {
printf("Volume %d (:%d: %c:) mounted.\n",f,f+3,f+'C');
printf("Size: %d Kb, %d kB free.\n",FSGetVolumeSize(f)/1024,FSGetVolumeFree(f)/1024);
}
else {
// IF error==FS_BADVOLUME, THEN THERE IS NO VOLUME f IN THE CURRENTLY INSERTED CARD
if(error!=FS_BADVOLUME) printf("Error=%s\n",FSGetErrorMsg(error));
}
}

// SET/GET CURRENT VOLUME

for(f=0;f<4;++f)
{
error=FSSetCurrentVolume(f);
if(error==FS_OK) printf("Curr. vol. changed to :%d:\n",f+3);
else {
printf("Error: %s\n",FSGetErrorMsg(error));
}
printf("Current volume is :%d:\n",FSGetCurrentVolume(f)+3);

}

keyb_getkey(1);

// CARD DETECTION TEST

printf("Card detection test, press ON to exit\n");
printf("Take the card out\n");

do {
error=FSVolumeInserted(FSGetCurrentVolume());
if(keyb_isON()) break;
} while(error==FS_OK);

if(error==FS_NOCARD) {
printf("Insert the same card back or a different card\n");

do {
error=FSVolumeInserted(FSGetCurrentVolume());
if(keyb_isON()) break;
} while(error==FS_NOCARD);

printf(FSGetErrorMsg(error));
printf("\n");
if(error==FS_OK) printf("Same card is back in\n");
if(error==FS_CHANGED) {
printf("Card was changed, insert the original card back\n");
do {
error=FSVolumeInserted(FSGetCurrentVolume());
if(keyb_isON()) break;
} while(error!=FS_OK);

if(error==FS_OK) printf("Same card is back in\n");
}

}

// NOT REALLY NEEDED, SHUTDOWN IS CALLED AUTOMATICALLY
// BUT IT'S ALWAYS A GOOD IDEA TO CALL IT MANUALLY AND CHECK
// FOR ERRORS
error=FSShutdown();
if(error==FS_OK) printf("Shutdown OK\n");
else printf("Shutdown error: %s", FSGetErrorMsg(error));


printf("Exit\n");
keyb_getkey(1);


return 0;
}




