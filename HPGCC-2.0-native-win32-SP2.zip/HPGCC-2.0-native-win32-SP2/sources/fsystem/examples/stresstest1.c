//@<head>
//& <prolog>
//& ****************************************************************************
//&
//& Written by Claudio Lapilli, February 2006
//&
//& Copyright (C) 2006 HP-GCC Development Team
//&
//& ****************************************************************************
//&
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//&
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************

//& </prolog>

// $Header: /cvsroot/hpgcc/sources/fsystem/examples/directories.c


// STRESS TEST FOR BASIC FUNCTIONS

#include <hpgcc49.h>

#include <fsystem.h>

int main()
{
int error,error2;
int f;
FS_FILE *file,*file2;


clear_screen();

// SHOW INFORMATION ABOUT MOUNTED VOLUMES
for(f=0;f<4;++f)
{
error=FSVolumeInserted(f);
if(error==FS_OK)
 {
printf("Volume %d (:%d: %c:) mounted.\n",f,f+3,f+'C');
printf("Size: %d Kb, %d kB free.\n",FSGetVolumeSize(f)/1024,FSGetVolumeFree(f)/1024);
}
else {
// IF error==FS_BADVOLUME, THEN THERE IS NO VOLUME f IN THE CURRENTLY INSERTED CARD
if(error!=FS_BADVOLUME) printf("Error=%s\n",FSGetErrorMsg(error));
}
}

// START TESTS
printf("*** FSMkdir ***\n");
// TESTING Mkdir
f=0;
// CREATE A DIRECTORY
error=FSMkdir("Test Dir");
printf("test %d=%s\n",f,FSGetErrorMsg(error));

++f;
// CREATE A DIRECTORY THAT ALREADY EXISTS
error=FSMkdir("Test Dir");
printf("test %d=%s\n",f,FSGetErrorMsg(error));

++f;
// CREATE A DIRECTORY WITH INVALID NAME
error=FSMkdir("INVALID::DIR");
printf("test %d=%s\n",f,FSGetErrorMsg(error));

keyb_getkey(1);


printf("*** FSCreate ***\n");


// TESTING FSCREATE
++f;
// CREATE A FILE WITH INVALID NAME
error=FSCreate("INVALID::DIR",0,&file);
printf("test %d=%s\n",f,FSGetErrorMsg(error));
if(error==FS_OK) FSClose(file);

++f;
// CREATE A FILE WITH PATH
error=FSCreate("Test Dir/Test File",0,&file);
printf("test %d=%s\n",f,FSGetErrorMsg(error));
if(error==FS_OK) FSClose(file);

++f;
// CREATE A FILE WITH INVALID PATH
error=FSCreate("Test Dir/Test File/Test File",0,&file);
printf("test %d=%s\n",f,FSGetErrorMsg(error));
if(error==FS_OK) FSClose(file);

++f;
// CREATE A FILE THAT ALREADY EXISTS
error=FSCreate("Test Dir",0,&file);
printf("test %d=%s\n",f,FSGetErrorMsg(error));
if(error==FS_OK) FSClose(file);


keyb_getkey(1);

// BACK TO MKDIR
printf("*** FSMkdir ***\n");

++f;
// TESTING MKDIR WITH INVALID PATH
error=FSMkdir("Test Dir\\Test File\\Newdir");
printf("test %d=%s\n",f,FSGetErrorMsg(error));

keyb_getkey(1);

printf("*** FSRmdir ***\n");

++f;
// TRY TO REMOVE INVALID DIR
error=FSRmdir("Test Dir\\Test File");
printf("test %d=%s\n",f,FSGetErrorMsg(error));

++f;
// TRY TO REMOVE USED DIRECTORY
error=FSRmdir("Test Dir");
printf("test %d=%s\n",f,FSGetErrorMsg(error));

++f;
// TRY TO REMOVE ROOT DIR
error=FSRmdir("\\");
printf("test %d=%s\n",f,FSGetErrorMsg(error));


keyb_getkey(1);


// OPEN TESTS

printf("*** FSOpen ***\n");


++f;
// OPEN A FILE
error=FSOpen("Test Dir/Test File",FSMODE_READ,&file);
printf("test %d=%s\n",f,FSGetErrorMsg(error));

++f;
// OPEN SAME FILE TWICE
error2=FSOpen("Test Dir/Test File",FSMODE_WRITE,&file2);
printf("test %d=%s\n",f,FSGetErrorMsg(error2));
if(error2==FS_OK) FSClose(file2);

keyb_getkey(1);

printf("*** FSDelete+FSRename ***\n");

++f;
// DELETE AN OPEN FILE
error2=FSDelete("Test Dir/Test File");
printf("test %d=%s\n",f,FSGetErrorMsg(error2));

++f;
// RENAME AN OPEN FILE
error2=FSRename("Test Dir/Test File","Test Dir/TEST FILE");
printf("test %d=%s\n",f,FSGetErrorMsg(error2));

if(error==FS_OK) FSClose(file);

++f;
// RENAME THE FILE
error2=FSRename("Test Dir/Test File","Test Dir/TEST FILE");
printf("test %d=%s\n",f,FSGetErrorMsg(error2));

++f;
// RENAME INEXISTENT FILE
error2=FSRename("Test Dir/Test File","Test Dir/TEST FILE");
printf("test %d=%s\n",f,FSGetErrorMsg(error2));

++f;
// DELETE INEXISTENT FILE
error2=FSDelete("Test Dir/Test File");
printf("test %d=%s\n",f,FSGetErrorMsg(error2));

++f;
// DELETE FILE
error2=FSDelete("Test Dir/TEST FILE");
printf("test %d=%s\n",f,FSGetErrorMsg(error2));

keyb_getkey(1);

printf("*** FSRmdir ***\n");

++f;
// TRY REMOVE EMPTY DIR
error=FSRmdir("Test Dir");
printf("test %d=%s\n",f,FSGetErrorMsg(error));

// END TESTS

// NOT REALLY NEEDED, SHUTDOWN IS CALLED AUTOMATICALLY
// BUT IT'S ALWAYS A GOOD IDEA TO CALL IT MANUALLY AND CHECK
// FOR ERRORS
error=FSShutdown();
if(error==FS_OK) printf("Shutdown OK\n");
else printf("Shutdown error: %s", FSGetErrorMsg(error));


printf("Exit\n");
keyb_getkey(1);


return 0;
}




