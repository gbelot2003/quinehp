//@<head>
//& <prolog>
//& ****************************************************************************
//&
//& Written by Claudio Lapilli, February 2006
//&
//& Copyright (C) 2006 HP-GCC Development Team
//&
//& ****************************************************************************
//&
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//&
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************

//& </prolog>

// $Header: /cvsroot/hpgcc/sources/fsystem/examples/directories.c


// STRESS TEST FOR BASIC FUNCTIONS

#include <hpgcc49.h>

#include <fsystem.h>

int main()
{
int error;
int f,v;
FS_FILE *files[20];

char helloworld[]="\nHello world!\n";
char *tempstring;


clear_screen();

// SHOW INFORMATION ABOUT MOUNTED VOLUMES
for(v=0;v<4;++v)
{
if(FSVolumeInserted(v)==FS_OK) {
printf("Volume %d (:%d: %c:) mounted.\n",v,v+3,v+'C');

FSSetCurrentVolume(v);
// START TESTS
printf("*** FSOpen 11 files ***\n");

// TESTING MULTIPLE FILES
f=0;
error=FSOpen("Test File",FSMODE_APPEND,&(files[f]));
printf("file %d=%s\n",f,FSGetErrorMsg(error));
if(error!=FS_OK) files[f]=NULL;

++f;
error=FSOpen("test File",FSMODE_APPEND,&(files[f]));
printf("file %d=%s\n",f,FSGetErrorMsg(error));
if(error!=FS_OK) files[f]=NULL;

++f;
error=FSOpen("test file",FSMODE_APPEND,&(files[f]));
printf("file %d=%s\n",f,FSGetErrorMsg(error));
if(error!=FS_OK) files[f]=NULL;

++f;
error=FSOpen("TEST file",FSMODE_APPEND,&(files[f]));
printf("file %d=%s\n",f,FSGetErrorMsg(error));
if(error!=FS_OK) files[f]=NULL;

++f;
error=FSOpen("test FILE",FSMODE_APPEND,&(files[f]));
printf("file %d=%s\n",f,FSGetErrorMsg(error));
if(error!=FS_OK) files[f]=NULL;

++f;
error=FSOpen("TEst FIle",FSMODE_APPEND,&(files[f]));
printf("file %d=%s\n",f,FSGetErrorMsg(error));
if(error!=FS_OK) files[f]=NULL;

printf("Press a key\n");
keyb_getkey(1);


++f;
error=FSOpen("teST fiLE",FSMODE_APPEND,&(files[f]));
printf("file %d=%s\n",f,FSGetErrorMsg(error));
if(error!=FS_OK) files[f]=NULL;

++f;
error=FSOpen("teST FIle",FSMODE_APPEND,&(files[f]));
printf("file %d=%s\n",f,FSGetErrorMsg(error));
if(error!=FS_OK) files[f]=NULL;

++f;
error=FSOpen("TeSt FiLe",FSMODE_APPEND,&(files[f]));
printf("file %d=%s\n",f,FSGetErrorMsg(error));
if(error!=FS_OK) files[f]=NULL;

++f;
error=FSOpen("tEsT fIlE",FSMODE_APPEND,&(files[f]));
printf("file %d=%s\n",f,FSGetErrorMsg(error));
if(error!=FS_OK) files[f]=NULL;

++f;
error=FSOpen("TEST FILE",FSMODE_APPEND,&(files[f]));
printf("file %d=%s\n",f,FSGetErrorMsg(error));
if(error!=FS_OK) files[f]=NULL;


printf("Press a key\n");
keyb_getkey(1);


printf("*** FSWrite ***\n");


for(f=0;f<11;++f)
{
if(files[f]) {
tempstring=FSGetFileName(files[f],FSNAME_HASVOL | FSNAME_VOLHP | FSNAME_HASPATH | FSNAME_ABSPATH);
if(tempstring) {
error=FSWrite(tempstring,strlen(tempstring),files[f]);
free(tempstring);
}
else { error=0; printf("FSGetFileName failed\n"); }
error+=FSWrite(helloworld,strlen(helloworld),files[f]);
printf("write %d=%d bytes\n",f,error);
} else {
printf("file %d is not open\n",f);
}
if(f==5) {printf("Press a key\n");
keyb_getkey(1);
}

}

printf("Press a key\n");
keyb_getkey(1);

// CLOSE ALL FILES

printf("*** FSClose ***\n");

for(f=0;f<11;++f)
{
if(files[f]) {
error=FSClose(files[f]);
printf("closing file %d=%s\n",f,FSGetErrorMsg(error));
}  else {
printf("file %d is not open\n",f);
}
if(f==5) { printf("Press a key\n");
keyb_getkey(1);
}
}

printf("Press a key\n");
keyb_getkey(1);

}
// END TESTS

}

// NOT REALLY NEEDED, SHUTDOWN IS CALLED AUTOMATICALLY
// BUT IT'S ALWAYS A GOOD IDEA TO CALL IT MANUALLY AND CHECK
// FOR ERRORS
error=FSShutdown();
if(error==FS_OK) printf("Shutdown OK\n");
else printf("Shutdown error: %s", FSGetErrorMsg(error));


printf("Exit\n");
keyb_getkey(1);

return 0;
}




