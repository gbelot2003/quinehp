//@<head>
//& <prolog>
//& ****************************************************************************
//&
//& Written by Claudio Lapilli, February 2006
//&
//& Copyright (C) 2006 HP-GCC Development Team
//&
//& ****************************************************************************
//&
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//&
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************

//& </prolog>

// $Header: /cvsroot/hpgcc/sources/fsystem/examples/directories.c


// DIRECTORY MANAGEMENT FUNCTIONS EXAMPLE (MKDIR, CHDIR, RMDIR)


#include <hpgcc49.h>

#include <fsystem.h>


int main()
{
int error;
int f;
FS_FILE *file;
char helloworld[]="Hello world!\n";

clear_screen();

// SHOW INFORMATION ABOUT MOUNTED VOLUMES
for(f=0;f<4;++f)
{
error=FSVolumeInserted(f);
if(error==FS_OK)
 {
printf("Volume %d (:%d: %c:) mounted.\n",f,f+3,f+'C');
printf("Size: %d Kb, %d kB free.\n",FSGetVolumeSize(f)/1024,FSGetVolumeFree(f)/1024);
}
else {
// IF error==FS_BADVOLUME, THEN THERE IS NO VOLUME f IN THE CURRENTLY INSERTED CARD
if(error!=FS_BADVOLUME) printf("Error=%s\n",FSGetErrorMsg(error));
}
}
// SET/GET CURRENT VOLUME

for(f=0;f<4;++f)
{
error=FSSetCurrentVolume(f);
if(error==FS_OK) {
printf("Curr. vol. changed to :%d:\n",f+3);

// CREATE TEST DIRECTORY

error=FSMkdir("Test Dir");
if(error==FS_EXIST) printf("Test dir already present\n");
else {
if(error!=FS_OK) {
printf("Error=%s\n",FSGetErrorMsg(error));
printf("Aborting test on this volume\n");
keyb_getkey(1);
continue;
}
}
error=FSChdir("Test Dir");
if(error!=FS_OK) printf("Unable to change to test dir\n");


error=FSMkdir("Subdir");
if(error!=FS_OK) printf("Unable to create subdir=%s\n",FSGetErrorMsg(error));




// CREATE TEST FILES

error=FSOpen("Test file 1",FSMODE_WRITE, &file);
printf("Test file 1 open returned:\n%s\n",FSGetErrorMsg(error));
if(error!=FS_OK) {
printf("Aborting test on this volume\n");
keyb_getkey(1);
continue;
}

if(FSWrite(helloworld,strlen(helloworld),file)!=strlen(helloworld))
{
printf("Problem writing test file\n");
}

error=FSClose(file);
if(error!=FS_OK) {
printf("FSClose error=%s\n",FSGetErrorMsg(error));
}

// REOPEN THE FILE FOR APPEND

error=FSOpen("Test file 1",FSMODE_APPEND, &file);
printf("Test file 1 open returned:\n%s\n",FSGetErrorMsg(error));
if(error!=FS_OK) {
printf("Aborting test on this volume\n");
keyb_getkey(1);
continue;
}

if(FSWrite("Appended string",17,file)!=17)
{
printf("Problem appending to test file\n");
}

error=FSClose(file);
if(error!=FS_OK) {
printf("FSClose error=%s\n",FSGetErrorMsg(error));
}

// REOPEN FILE FOR MODIFY


error=FSOpen("Test file 1",FSMODE_MODIFY, &file);
printf("Test file 1 open returned:\n%s\n",FSGetErrorMsg(error));
if(error!=FS_OK) {
printf("Aborting test on this volume\n");
keyb_getkey(1);
continue;
}

FSSeek(file,6,SEEK_SET);


if(FSWrite("HP49G+",6,file)!=6)
{
printf("Problem modifying test file\n");
}

error=FSCloseAndDelete(file);
if(error!=FS_OK) {
printf("FSClose error=%s\n",FSGetErrorMsg(error));
}


error=FSRename("My own text document.txt","\\Another document.bin");
printf("rename=%s\n",FSGetErrorMsg(error));

error=FSRmdir("Subdir");
if(error!=FS_OK) printf("Unable to remove subdir=%s\n",FSGetErrorMsg(error));


keyb_getkey(1);
}

}


// NOT REALLY NEEDED, SHUTDOWN IS CALLED AUTOMATICALLY
// BUT IT'S ALWAYS A GOOD IDEA TO CALL IT MANUALLY AND CHECK
// FOR ERRORS
error=FSShutdown();
if(error==FS_OK) printf("Shutdown OK\n");
else printf("Shutdown error: %s", FSGetErrorMsg(error));



printf("Exit\n");
keyb_getkey(1);

return 0;
}




