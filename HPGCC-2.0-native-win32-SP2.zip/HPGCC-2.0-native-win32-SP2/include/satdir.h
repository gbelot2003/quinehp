//@<head>
//& <prolog>
//& ****************************************************************************
//&
//& Written by Ingo Blank & Claudio Lapilli
//&
//& Low level routines by Claudio Lapilli, Copyright (C) 2005 Claudio Lapilli
//& High level API by Ingo Blank,  Copyright (C) 2005 Ingo Blank
//&
//& Copyright (C) 2005 Blank, Lapilli, HP-GCC Development Team
//&
//& ****************************************************************************
//&
//&
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//&
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************

//& </prolog>

// $Header: satdir.h , 2005/08/13 16:18:06 , ingo Exp $

//@</head>

#ifndef __SAT_DIR_H
#define __SAT_DIR_H

/*!
 * \file satdir.h
 * \brief Low level Saturn directory access with high level C API on top
 *
 * \todo Add low level API documentation
 */
 

#define SAT_CONTEXT 0x8071b
#define SAT_USEROB  0x80711

// --- DATA STRUCTURES

/*!
 * \brief A Saturn domain Object descriptor
 * \code
 *   typedef
 *   struct _sat_obj_dscr {
 *       char *name;
 *       unsigned addr;
 *   } SAT_OBJ_DSCR;
 * \endcode
 */
 
typedef
struct _sat_obj_dscr {
    char *name;
    unsigned addr;
} SAT_OBJ_DSCR;

/*!
 * \brief A Saturn domain directory entry, modeled for C access
 *
 * Directory entries are records consisting of a pointer to an \a Object descriptor, and a linked list pointer to all directory elements. 
 *
 * \code
 *  typedef
 *      struct _sat_dir_entry {
 *          SAT_OBJ_DSCR *sat_obj;       
 *          struct _sat_dir_entry *next;
 *  } SAT_DIR_ENTRY;
 * \endcode
 */


typedef
struct _sat_dir_entry {
        SAT_OBJ_DSCR *sat_obj;       
        struct _sat_dir_entry *next;
} SAT_DIR_ENTRY;

/*!
 * \brief A Saturn doamin directory node, modeled for C access.
 *
 * The Saturn domain directory is modeled as a n-ary tree,
 * which is recursively defined with three pointers.
 * \a parent for climbing up the hierarchy towards root,
 * \a sibling for a chained list of directories on the same level and
 * \a child for the next subtree beneath the current folder.
 *
 * \code
 *  typedef
 *      struct _sat_dir_node {
 *          char *name;
 *          truct _sat_dir_node *parent,*sibling,*child;
 *          struct _sat_dir_entry *object;
 *  } SAT_DIR_NODE;
 * \endcode
 */

typedef
struct _sat_dir_node {
        char *name;
        struct _sat_dir_node *parent,*sibling,*child;
        struct _sat_dir_entry *object;
} SAT_DIR_NODE;

/*!
 * \brief A generic string list
 * \code
 *  typedef
 *  struct _sat_dir_slist {
 *      char *str;
 *        struct _sat_dir_slist *next;
 *  } SAT_DIR_SLIST;
 * \endcode
 */

typedef
struct _sat_dir_slist {
    char *str;
    struct _sat_dir_slist *next;
} SAT_DIR_SLIST;

// --- GLOBALS

extern SAT_DIR_NODE *__sat_cwd, *__sat_root;

// --- LOW LEVEL SATURN DIR HANDLING

// TODO: Add low level API documentation

int sat_skipob(int objaddr);
int sat_objgetdir(int objaddr);
int sat_dircurrent();
int sat_objcurdir();
int sat_dirhome();
int sat_objhome();
int sat_dirfindfirst(int diraddr);
int sat_dirfindnext(int diritem);
int sat_itemgetdir(int itemaddr);
int sat_sknameup(int itemaddr);
int sat_sknamedn(int objaddr);
int sat_objgetitem(int objptr);
int sat_itemgetname(int diritem,char *name);

// --- LOCAL HELPERS

/*!
    \fn        SAT_DIR_NODE *_sat_find_path(char *path)
    \brief    Find the internal directory node for path \b "path"
            
            DON'T CALL EXPLICITLY
*/

SAT_DIR_NODE *_sat_find_path(char *path);

/*!
    \fn char *_sat_dir_path(SAT_DIR_NODE *P)
    \brief return a string representation of the path leading to node P
*/

char *_sat_dir_path(SAT_DIR_NODE *p);

/*!
 * \brief PRIVATE DON'T CALL
 */
 
SAT_DIR_NODE *_sat_dir_getroot();

/*!
 * \brief PRIVATE DON'T CALL
 */

SAT_DIR_NODE *_sat_dir_getcwd();

/*!
    \fn        void _sat_dir_destroy_slist(SAT_DIR_SLIST *s)
    \param  s Pointer to string list
    \brief    Destroy a string list, built by sat_dir_searchobject(). Frees all associated memory.
*/


void _sat_dir_destroy_slist(SAT_DIR_SLIST *s);

/*!    
    \fn        void _sat_dir_split_path(char *path,char **dir, char **base)    
    \param  path A string, representing a path 
    \param  dir Address of pointer for the directory oart
    \param  base Address of pointer of the filename part
    \brief     Split a pathname into \b dir and \b base components.
            Usually not to be called directly
*/

void _sat_dir_split_path(char *path,char **dir, char **base);
int _sat_dir_getprolog(SAT_OBJ_DSCR *obj);

// --- HIGH LEVEL "HIDDEN" API (DON'T USE EXPLICITLY)

/*!
    \fn     sat_dir_open()
    \brief    Open (create) the internal directory structures.
            Not to be called directly!
*/

void sat_dir_open();

/*!
    \fn        void sat_dir_close(SAT_DIR_NODE *p)
    \brief    Close (destroy) the internal data structures
            May be called explicitly, to recover memory.
*/


void sat_dir_close();

//  --- HIGH LEVEL DIR  API 

/*!
    \fn char *sat_dir_curdir()
    \return A string, representing the current directory
    \brief return a string representation of the current (working) directory
*/

char *sat_dir_curdir();

/*!
    \fn        int sat_dir_chdir(char *path)    
    \brief    Change the \b internal path (not calculator!) to \b path
    \return    0 if successful
*/


int sat_dir_chdir(char *path);

/*!
    \fn        SAT_OBJ_DSCR * sat_dir_getobject(char *path)
    \brief    Return a pointer to an object descriptor for object at \b path
    \param  path Path to the object
    \return    A pointer to a SAT_OBJ_DSCR or NULL if not found

    \b path may be absolute or relative. If absolute, the search starts at root (HOME)
    Or at \b sat_dir_curdir(), if relative

*/

SAT_OBJ_DSCR *sat_dir_getobject(char *path);

/*!
    \fn        SAT_OBJ_DSCR * sat_dir_rclobject(char *path)
    \param  path Path to the object
    \brief    Similar to sat_dir_getobject, but with \b RCL semantics.
            I.e. if the object is not found in the cureent dir, the search continues
            up the path towards root.
*/


SAT_OBJ_DSCR *sat_dir_rclobject(char *path);

/*!
    \fn        int sat_dir_searchobject(char *name,SAT_DIR_SLIST **res)
    \param  name The object's name
    \param  path_list Address of a pointer to a string list
    \brief    Search for object named \b "name" down the whole directory tree.
    \return    The number of found objects and a result set (string list) \b res, containing the full paths
*/


int sat_dir_searchobject(char *name, SAT_DIR_SLIST **path_list);

// --- DATA ACCESS API

/*!
 * \fn      int sat_obj_is_real(SAT_OBJ_DSCR *obj)
 * \brief   Logical inquiry function, whether an object represents a \a REAL 
 * \param   obj Pointer to an \a Object \a descriptor
 * \return  non zero if obj is a real, zero otherwise
 */ 
 
int sat_obj_is_real(SAT_OBJ_DSCR *obj);

/*!
    \fn        double _sat_dir_fetchreal(char *path, double defval, char *mode)
    \brief    Return the double object at \a path or \a defval if not found.
    \param  path The path to the object
    \param  defval A default value to be returned, if not found
    \param  mode A string "g" (get) or "r" (recall), describing the fetch semantics
    \return    A real value, either object@path or defval
*/

double _sat_dir_fetchreal(char *path, double defval, char *mode);

/*! \def sat_dir_getreal(p,v)
 *  \brief Get real at p(ath) or default v(alue)
 */
 
#define sat_dir_getreal(p,v) _sat_dir_fetchreal((p),(v),"g")

/*! \def sat_dir_rclreal(p,v)
 *  \brief Recall real at p(ath) or default v(alue)
 */
 
#define sat_dir_rclreal(p,v) _sat_dir_fetchreal((p),(v),"r")

#endif
