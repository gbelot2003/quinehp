#ifndef __HPGCC_CONFIG_H
#define __HPGCC_CONFIG_H

/*!
  * \file hpgcc_config.h
  * \brief Configuration constants for the hpgcc runtime libraries
  *
  */

/*!
  * \brief The library revision number
  */
  
#define HPGCC_VERSION 2.0

/*!
  * \brief The library major revision number
  */
 

#define HPGCC_VERSION_MAJOR 2

/*!
  * \brief The library minor revision number
  */
 
#define HPGCC_VERSION_MINOR 0

/*!
  \brief Activate patch for broken kos_fopen() mode "a" workaround
  
  The kos_fopen() is broken when called with the "a" (append) mode paramter,
  in that respect, that it doesn't create the file, if it doesn't exist.
  This define controls the workaround patch.
  Set to 1 to activate.

*/

// < ibl ; 2005-09-06 >

#define PATCH_BROKEN_KOS_FOPEN_APPEND 1


/*!
   \brief Force uppercase filenames in fopen()
  
   Set to 1 to force filenames for fopen() to uppercase
   to workaround buggy/sloppy FAT-FS implementation in KOS.
   Background: Files with lowercase letters created on the calculator
   can't be read by Windows...
 */
 
// < ibl 2005-12-07 > 

#define PATCH_FOPEN_FORCE_UPPERCASE 1

/*!
  \brief Is there a bias for the RPL stack ?
  
  Controls appropriate code generation.
  Set to 1 for ARM Toolbox version < 3.0 

*/

// < ibl ; 2005-09-06 >

#define HAVE_STACK_BIAS 0

#endif
