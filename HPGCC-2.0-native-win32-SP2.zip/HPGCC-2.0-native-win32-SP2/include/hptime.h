//& ****************************************************************************
//&
//& Written by Ingo Blank, Benjamin Maurin August 2004
//&
//& Copyright (C) 2004 The HP-GCC Development Team
//&
//& ****************************************************************************
//&
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//&
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************

// $Header: /cvsroot/hpgcc/sources/hplib/hptime.h,v 1.3 2005/06/23 12:29:05 iblank Exp $

/*!    \file    time.h
    \brief    The Time Library for HP49 gcc
*/

#ifndef _HPTIME_H
#define _HPTIME_H


#define CLOCKS_PER_SEC    60    

#ifdef _POSIX_SOURCE
#define CLK_TCK CLOCKS_PER_SEC    
#endif

#ifndef NULL
#define NULL    ((void *)0)
#endif


#ifndef _TIME_T
#define _TIME_T
typedef long time_t;        /* time in sec since 1 Jan 1970 0000 GMT */
#endif

#ifndef _CLOCK_T
#define _CLOCK_T
typedef long clock_t;        /* time in ticks since process started */
#endif

struct tm {
  int tm_sec;            /* seconds after the minute [0, 59] */
  int tm_min;            /* minutes after the hour [0, 59] */
  int tm_hour;            /* hours since midnight [0, 23] */
  int tm_mday;            /* day of the month [1, 31] */
  int tm_mon;            /* months since January [0, 11] */
  int tm_year;            /* years since 1900 */
  int tm_wday;            /* days since Sunday [0, 6] */
  int tm_yday;            /* days since January 1 [0, 365] */
  int tm_isdst;            /* Daylight Saving Time flag */
};


void sys_tm_RTC(struct tm *);

char *_isotime(const struct tm *, int strict_iso);
#define isotime(tm) _isotime((tm),0)
char *asctime(const struct tm *); 


//extern char *tzname[];



#endif 
