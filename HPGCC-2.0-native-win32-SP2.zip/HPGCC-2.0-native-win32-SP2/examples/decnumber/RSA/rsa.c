/* ------------------------------------------------------------------ */
/* Decimal Number Library Demonstration program                       */
/* ------------------------------------------------------------------ */
/* Copyright (c) Ingo Blank 2006  All rights reserved.                */
/* ----------------------------------------------------------------+- */
/*                                                 right margin -->|  */

// numth.c -- Number Theory related functions, 
// demontrating RSA public key cryptography.

// $Id: rsa.c 317 2006-10-28 15:20:48Z ingo $

#define  DECNUMDIGITS 500           

#include "decNumber.h"             // base number library
#include "decNumberLocal.h"

#include <hpgcc49.h>

#ifndef max
#define max(a,b) (a) > (b) ? (a) : (b)
#endif

#ifndef min
#define min(a,b) (a) < (b) ? (a) : (b)
#endif




typedef struct {
    int32_t digits;
    int32_t exponent;
    uint8_t bits;
} decNumberPrologue;

#define decNumberSize(digits) (2*sizeof(int32_t)+sizeof(uint8_t) + D2U((digits)) * sizeof(decNumberUnit))

void free2(void *a, void *b)
{
    free(a);
    free(b);
}

void
free3(void *a, void *b, void *c)
{
    free2(a,b);
    free(c);
}

void 
free4(void *a, void *b, void *c, void *d)
{
    free2(a,b);
    free2(c,d);
}

void 
free5(void *a, void *b, void *c, void *d, void *e)
{
    free3(a,b,c);
    free2(d,e);
}

void 
free6(void *a, void *b, void *c, void *d, void *e, void *f)
{
    free3(a,b,c);
    free3(d,e,f);
}


int 
sq(int x)
{
    return x*x;
}

int 
ipow10(int n)
{
    if (n == 0)
        return 1;
    if (n & 1)
        return 10 * ipow10(n-1);
    
    return sq(ipow10(n/2));
}
    


int 
_ilog10(int n)
{
    int p = 10, t = 1;
    if (n < 0)
        return _ilog10(-n);
    for(;;) {
        if ( n < p )
            return t;
        p *= 10;
        t++;
    }
}

 



decNumber *
decNumberAlloc(int digits)
{
    return (decNumber *) calloc(1,decNumberSize(digits));
}


void
decNumberPrint(decNumber * num)
{
    char           *s = (char *) malloc(num->digits + 10);

    decNumberToString(num, s);
    printf("%s ", s);
    free(s);
}

void
decNumberPrintLn(decNumber * num)
{
    decNumberPrint(num);
    printf("\n");
}

int
decNumberIsOdd(decNumber *a)
{
    return *((decNumberUnit *) (a->lsu)) & 1;
}

int
decNumberIsEven(decNumber *a)
{
    return !(a->lsu[0] & 1);
}

int
decNumberIsLess(decNumber *a, decNumber *b, decContext *ctx)
{
    decNumber cmp;
    
    decNumberCompare(&cmp,a,b,ctx);
    return decNumberIsNegative(&cmp);
}

int
decNumberIsGreater(decNumber *a, decNumber *b, decContext *ctx)
{
    decNumber cmp;
    
    decNumberCompare(&cmp,a,b,ctx);
    return !(decNumberIsNegative(&cmp) || decNumberIsZero(&cmp));
}


int
decNumberIsEqual(decNumber *a, decNumber *b, decContext *ctx)
{
    decNumber cmp;
    
    decNumberCompare(&cmp,a,b,ctx);
    return decNumberIsZero(&cmp);
}





/*
decNumber *
decNumberCopy(decNumber *t, decNumber *s)
{
    return (decNumber *) memcpy(t,s,decNumberSize(s->digits));
}
*/

decNumber *
decNumberSaveCopy(decNumber *a, decNumber *b)
{
    decNumber *z;
    
    if (b->digits > a->digits) {
        z = decNumberAlloc(b->digits);
        decNumberCopy(z,a);
        free(a);
        a = z;
    }
    
    return decNumberCopy(a,b);
}


decNumber *
decNumberAllocAssign(decNumber *rhs)
{
    decNumber *lhs;
    
    lhs = decNumberAlloc(rhs->digits);
    return decNumberCopy(lhs,rhs);
}

decNumber *
decNumberAllocAssignConst(char *rhs,decContext *ctx)
{
    decNumber *lhs;
    
    lhs = decNumberAlloc(strlen(rhs));
    decNumberFromString(lhs,rhs,ctx);
    
    return lhs;
}


decNumber *
decNumberAddAlloc(decNumber *a, decNumber *b, decContext *ctx)
{
    decContext save = *ctx;
    decNumber *z;
    
    ctx->digits = max(a->digits,b->digits)+1;
    z = decNumberAlloc(ctx->digits);
    decNumberAdd(z,a,b,ctx);
    
    *ctx = save;
    
    return z;
}

decNumber *
decNumberSubAlloc(decNumber *a, decNumber *b, decContext *ctx)
{
    decContext save = *ctx;
    decNumber *z;
    
    ctx->digits = max(a->digits,b->digits)+1;
    z = decNumberAlloc(ctx->digits);
    decNumberSubtract(z,a,b,ctx);
    
    *ctx = save;
    
    return z;
}



decNumber *
decNumberMultiplyAlloc(decNumber *a, decNumber *b, decContext *ctx)
{
    decContext save = *ctx;
    decNumber *z;
    
    ctx->digits = a->digits+b->digits;
    z = decNumberAlloc(ctx->digits);
    decNumberMultiply(z,a,b,ctx);
    
    *ctx = save;
    
    return z;
}



decNumber *
decNumberModuloAlloc(decNumber *a, decNumber *b, decContext *ctx)
{
    
    decContext save = *ctx;
    decNumber *z;
    
    ctx->digits = a->digits;
    z = decNumberAlloc(ctx->digits);
    decNumberRemainder(z,a,b,ctx);
    
    *ctx = save;
    
    return z;
}

decNumber *
decNumberDivideIntegerAlloc(decNumber *a, decNumber *b, decContext *ctx)
{
    
    decContext save = *ctx;
    decNumber *z;
    
    
    ctx->digits = a->digits;
    z = decNumberAlloc(ctx->digits);
    decNumberDivideInteger(z,a,b,ctx);
    
    *ctx = save;
    
    return z;
}




decNumber *
decNumberFactorial(int n, decContext *ctx)
{
    
    decNumber *z,f,*one;
    decContext save;
    
    one = decNumberAlloc(1);
    decNumberFromString(one,"1",ctx);
    
    if (n <= 1)
        return one;
    
    save = *ctx;
    ctx->digits = (int) (log10((double)n)*n);
    z = decNumberAlloc(ctx->digits);
    decNumberCopy(z,one);
    decNumberCopy(&f,one);
    
    for(;n--;) {
        decNumberMultiply(z,z,&f,ctx);
        decNumberAdd(&f,&f,one,&save);
    }
    
    free(one);
    *ctx = save;
    
    return z;
}

/*
int
decNumberIsZero(decNumber *a)
{
    return a->lsu[0] == 0;
}
*/


decNumber *
decNumberExpMod(decNumber *x, decNumber *y, decNumber *n, decContext *ctx)
{
    decNumber *z,*s,*t,*u,*ONE,*TWO;
    decContext save = *ctx;
    
    ONE = decNumberAllocAssignConst("1",ctx);
    TWO = decNumberAllocAssignConst("2",ctx);
    
    s = decNumberAllocAssign(ONE);
    t = decNumberAllocAssign(x);
    u = decNumberAllocAssign(y);
    
    
   while (! decNumberIsZero(u)) { // while (u != 0)
       decNumber *u1;
       
       if(decNumberIsOdd(u)) {
           z = decNumberMultiplyAlloc(s,t,ctx);
           free(s);
           s = z;
           z = decNumberModuloAlloc(s,n,ctx);
           free(s);
           s = z;
       }
       
       //ctx->digits = max(ctx->digits,u->digits);
       u1 = decNumberDivideIntegerAlloc(u,TWO,ctx);
       free(u);
       u = u1;
       z = decNumberMultiplyAlloc(t,t,ctx);
       free(t);
       t = z;
       z = decNumberModuloAlloc(t,n,ctx);
       free(t);
       t = z;
       
    }
       
    
    free4(t,u,ONE,TWO);
    
    *ctx = save;
    
    return s;
    
}
 

decNumber *
decNumberPowInteger(decNumber *x, decNumber *y, decContext *ctx)
{
    
    decContext save = *ctx;
    decNumber *z,*s,*t,*u,*ONE,*TWO;
    int minus;
    
    if((minus = decNumberIsNegative(y))) 
        decNumberMinus(y,y,ctx);
    
    ONE = decNumberAllocAssignConst("1",ctx);
    TWO = decNumberAllocAssignConst("2",ctx);
    
    
    s = decNumberAllocAssign(ONE);
    t = decNumberAllocAssign(x);
    u = decNumberAllocAssign(y);

      
   while (! decNumberIsZero(u)) { // while (u != 0)
       
       if(decNumberIsOdd(u)) {
           z = decNumberMultiplyAlloc(s,t,ctx);
           free(s);
           s = z;
       }
       
       decNumberDivideInteger(u,u,TWO,ctx);
       z = decNumberMultiplyAlloc(t,t,ctx);
       free(t);
       t = z;
      
    }
       

    if (minus) {
        ctx->digits = min(s->digits,ctx->digits);
        decNumberDivide(s,ONE,s,ctx);
    }
    
    free4(t,u,ONE,TWO);
    *ctx = save;
    
    return s;
    
}
   
    
int
decNumberFermatTest(decNumber *n, decContext *ctx, int tests)
{
    decNumber a,cmp,ONE,*z;
    
    decNumberFromString(&ONE,"1",ctx);
    decNumberFromString(&a,"3",ctx);
    
    while (tests--) {
        z = decNumberExpMod(&a,n,n,ctx);
        decNumberCompare(&cmp,z,&a,ctx);
        free(z);
        if (!decNumberIsZero(&cmp))
            return 0;
        decNumberAdd(&a,&a,&ONE,ctx);
    }
    
    return 1;
}
        
        
decNumber *
decNumberRandom(int digits, decContext *ctx)
{
    decContext save = *ctx;
    decNumber TEN,*z;
    int i,r,m,p;
    decNumberUnit u;
    
    z = decNumberAlloc(digits);
    decNumberFromString(&TEN,"10",ctx);
    p = ipow10(DECDPUN);
    m = digits / DECDPUN;
    z->digits = 0;
    z->bits = 0;
    z->exponent = 0;
    
    for( i = 0; i < m; i++) {

        do {
             u = (decNumberUnit) (rand() % p);
        } while (_ilog10(u) < DECDPUN);
        
        z->lsu[i] = u;
        z->digits += DECDPUN;
    }
    
    if((r = digits - m * DECDPUN)) {
        p = ipow10(r);
        u = (decNumberUnit) (mwc(32) % p);
        z->lsu[i] = u;
        z->digits += _ilog10(u);
        ctx->digits = digits;
        while (z->digits < digits)
            decNumberMultiply(z,z,&TEN,ctx);
    }
    
    *ctx = save;
    
    return z;
}

   
decNumber *
decNumberPrime(int digits, decContext *ctx)
{
    decNumber TWO,*p;
    decContext save = *ctx;
    
    decNumberFromString(&TWO,"2",ctx);
    p = decNumberRandom(digits,ctx);
    p->lsu[0] |= 1; // Make odd
    ctx->digits = p->digits;
    while (! decNumberFermatTest(p,ctx,3)) {
        decNumberAdd(p,p,&TWO,ctx);
    }
    
    *ctx = save;
    
    return p;
}

decNumber *
decNumberGCD(decNumber *_a, decNumber *_b, decContext *ctx)
{

    decNumber *a,*b,*c;
    
    b = decNumberAllocAssign(_b);
    a = decNumberAllocAssign(_a);
    
    while (! decNumberIsZero(b) ) {
        c = decNumberModuloAlloc(a,b,ctx);
        a = decNumberSaveCopy(a,b);
        b = decNumberSaveCopy(b,c);
        free(c);
    }
    
    free(b);
    return a;
}

int
decNumberIsCoprime(decNumber *a, decNumber *b, decContext *ctx)
{
    
    decNumber ONE,cmp,*gcd;
    
    gcd = decNumberGCD(a,b,ctx);
   
    decNumberFromString(&ONE,"1",ctx);
    decNumberCompare(&cmp,gcd,&ONE,ctx);
    free(gcd);
    return decNumberIsZero(&cmp);
}

    

decNumber *
decNumberCoprimeFor(decNumber *a, decContext *ctx)
{
    decNumber *z, ONE;
    
    decNumberFromString(&ONE,"1",ctx);
    z = decNumberRandom(a->digits >= 4 ? a->digits/2 : a->digits, ctx);
   
    while (! decNumberIsCoprime(a,z,ctx))
        decNumberAdd(z,z,&ONE,ctx);
    
    return z;
}

decNumber *
decNumberInvMod(decNumber *a, decNumber *n, decContext *ctx)
{
    
    decNumber *s,*t,*c,*d;
    
    
    if (decNumberIsGreater(a,n,ctx))
        return decNumberInvMod(n,a,ctx);
    
    s = decNumberAllocAssign(n);
    t = decNumberAllocAssign(a);
    c = decNumberAllocAssignConst("0",ctx);
    d = decNumberAllocAssignConst("1",ctx);
    
    while (!decNumberIsZero(t)) {
        decNumber *q,*r,*z,*dq,*d1;
        
    
        q = decNumberDivideIntegerAlloc(s,t,ctx);
        r = decNumberModuloAlloc(s,t,ctx);
    
        s = decNumberSaveCopy(s,t);
        t = decNumberSaveCopy(t,r);
        
        z = decNumberAllocAssign(c);
        c = decNumberSaveCopy(c,d);
        dq = decNumberMultiplyAlloc(d,q,ctx);
        d1 = decNumberSubAlloc(z,dq,ctx);
        free(d);
        d = d1;
        
        free4(q,r,z,dq);
    }
    
    free3(s,t,d);
    
    if (decNumberIsNegative(c)) {
        decNumber *c1 =decNumberAddAlloc(c,n,ctx);
        free(c);
        c = c1;
    }
    
    return c;
}

        
        
    
typedef struct {
    decNumber *Private,*Public,*Modulus;
} RSA_Triple;

void
decNumberCreateRSATriple(RSA_Triple *rsa, int digitsP, int digitsQ,decContext *ctx)
{
    decNumber *P,*Q,*t,*p1,*q1;
    decNumber ONE;
    
    decNumberFromString(&ONE,"1",ctx);
    
    P = decNumberPrime(digitsP,ctx);
    Q = decNumberPrime(digitsQ,ctx);
    rsa->Modulus = decNumberMultiplyAlloc(P,Q,ctx);
    p1 = decNumberSubAlloc(P,&ONE,ctx);
    q1 = decNumberSubAlloc(Q,&ONE,ctx);
    t = decNumberMultiplyAlloc(p1,q1,ctx);
    rsa->Public = decNumberCoprimeFor(t,ctx);
    rsa->Private = decNumberInvMod(rsa->Public,t,ctx);
    
    free5(P,Q,t,p1,q1);
}

decNumber *
RSAEncrypt(RSA_Triple *rsa, decNumber *c, decContext *ctx)
{
    return decNumberExpMod(c,rsa->Public,rsa->Modulus,ctx);
}

decNumber *
RSADecrypt(RSA_Triple *rsa, decNumber *t, decContext *ctx)
{
    return decNumberExpMod(t,rsa->Private,rsa->Modulus,ctx);
}


void
testRSA(int digP, int digQ, decContext *ctx)
{
    RSA_Triple rsa;
    decNumber *T,*C,*t;
    
    decNumberCreateRSATriple(&rsa,digP,digQ,ctx);
    printf("Private: "); decNumberPrintLn(rsa.Private); 
    printf("Public:  "); decNumberPrintLn(rsa.Public); 
    printf("Modulus: "); decNumberPrintLn(rsa.Modulus);
    
    T = decNumberAllocAssignConst("1234567890",ctx);
    C = RSAEncrypt(&rsa,T,ctx);
    decNumberPrint(C);
    t = RSADecrypt(&rsa,C,ctx);
    decNumberPrintLn(t);
    
    
    
    printf("Test%sokay.\n",decNumberIsEqual(T,t,ctx) ? " " : " not ");
    
    free3(T,C,t);
}

    

int main() {

  decContext set;                  // working context
  int DP,DQ;
  
       
  srand(0);
  clear_screen();
  
  decContextDefault(&set, DEC_INIT_BASE); // initialize
  set.traps=0;                     // no traps, thank you
  set.digits=DECNUMDIGITS;         // set precision
 
 
   DQ = DP = 20;
   
   //DQ = (int) sat_pop_real();
   //DP = (int) sat_pop_real();
   
   
   while( DP + DQ > set.digits ) {
	DP >>= 1;
	DQ >>= 1;
   }
	
  
  if (DP + DQ > 30)
	sys_slowOff();
	
  testRSA(DP,DQ,&set);
  
  sys_slowOn();
  
  WAIT_CANCEL;

  return 0;
    
 
  } // main
