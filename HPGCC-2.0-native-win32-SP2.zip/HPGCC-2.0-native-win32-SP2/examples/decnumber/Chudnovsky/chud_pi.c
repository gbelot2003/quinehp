/* ------------------------------------------------------------------ */
/* Decimal Number Library Demonstration program                       */
/* ------------------------------------------------------------------ */
/* Copyright (c) Ingo Blank 2006  All rights reserved.                */
/* ----------------------------------------------------------------+- */
/*                                                 right margin -->|  */

/*
 * chud_pi.c
 * Arbitrary digits pi appoximation using Chudnvsky's formula. 
 */


// $Id: chud_pi.c 317 2006-10-28 15:20:48Z ingo $

#define HP 1

#define DECNUMDIGITS 5000

#include "decNumber.h"		// base number library
#include "decNumberLocal.h"

#ifdef PC
#include <stdio.h>		// for printf
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <signal.h>		// signal handling
#include <setjmp.h>		// setjmp/longjmp
#else

#define TINY_PRINTF 1
#include <hpgcc49.h>
#endif

#ifndef max
#define max(a,b) (a) > (b) ? (a) : (b)
#endif

#ifndef min
#define min(a,b) (a) < (b) ? (a) : (b)
#endif

#define decNumberSize(digits) (2*sizeof(int32_t)+sizeof(uint8_t) + D2U((digits)) * sizeof(decNumberUnit))

#ifdef PC
jmp_buf         preserve;	// stack snapshot

void
signalHandler(int sig)
{
    signal(SIGFPE, signalHandler);	// re-enable
    longjmp(preserve, sig);	// branch to preserved point
}

#endif


void
free2(void *a, void *b)
{
    free(a);
    free(b);
}

void
free3(void *a, void *b, void *c)
{
    free2(a, b);
    free(c);
}

void
free4(void *a, void *b, void *c, void *d)
{
    free2(a, b);
    free2(c, d);
}

void
free5(void *a, void *b, void *c, void *d, void *e)
{
    free3(a, b, c);
    free2(d, e);
}

void
free6(void *a, void *b, void *c, void *d, void *e, void *f)
{
    free3(a, b, c);
    free3(d, e, f);
}

int
sq(int x)
{
    return x * x;
}

int
ipow10(int n)
{
    if (n == 0)
	return 1;
    if (n & 1)
	return 10 * ipow10(n - 1);

    return sq(ipow10(n / 2));
}



int
_ilog10(int n)
{
    int             p = 10,
	t = 1;
    if (n < 0)
	return _ilog10(-n);
    for (;;) {
	if (n < p)
	    return t;
	p *= 10;
	t++;
    }
}



int
decNumberIsOdd(decNumber * a)
{
    return *((decNumberUnit *) (a->lsu)) & 1;
}

int
decNumberIsEven(decNumber * a)
{
    return !decNumberIsOdd(a);
}

int
decNumberIsLess(decNumber * a, decNumber * b, decContext * ctx)
{
    decNumber       cmp;

    decNumberCompare(&cmp, a, b, ctx);
    return decNumberIsNegative(&cmp);
}

int
decNumberIsGreater(decNumber * a, decNumber * b, decContext * ctx)
{
    decNumber       cmp;

    decNumberCompare(&cmp, a, b, ctx);
    return !(decNumberIsNegative(&cmp) || decNumberIsZero(&cmp));
}


int
decNumberIsEqual(decNumber * a, decNumber * b, decContext * ctx)
{
    decNumber       cmp;

    decNumberCompare(&cmp, a, b, ctx);
    return decNumberIsZero(&cmp);
}




decNumber      *
decNumberAlloc(int digits)
{
    return (decNumber *) calloc(1, decNumberSize(digits));
}

decNumber      *
decNumberSaveCopy(decNumber * a, decNumber * b)
{
    decNumber      *z;

    if (b->digits > a->digits) {
	z = decNumberAlloc(b->digits);
	decNumberCopy(z, a);
	free(a);
	a = z;
    }

    return decNumberCopy(a, b);
}


decNumber      *
decNumberAllocAssign(decNumber * rhs)
{
    decNumber      *lhs;

    lhs = decNumberAlloc(rhs->digits);
    return decNumberCopy(lhs, rhs);
}

decNumber      *
decNumberAllocAssignConst(char *rhs, decContext * ctx)
{
    decNumber      *lhs;

    lhs = decNumberAlloc(strlen(rhs));
    decNumberFromString(lhs, rhs, ctx);

    return lhs;
}


decNumber      *
decNumberFromInteger(int n, decContext * ctx)
{
    char            zbuff[10];

#ifdef PC
    sprintf(zbuff, "%d", n);
#else
    itoa(n, zbuff, 10);
#endif

    return decNumberAllocAssignConst(zbuff, ctx);
}



decNumber      *
decNumberAddAlloc(decNumber * a, decNumber * b, decContext * ctx)
{
    decContext      save = *ctx;
    decNumber      *z;

    ctx->digits = max(a->digits, b->digits) + 1;
    z = decNumberAlloc(ctx->digits);
    decNumberAdd(z, a, b, ctx);

    *ctx = save;

    return z;
}

decNumber      *
decNumberSubAlloc(decNumber * a, decNumber * b, decContext * ctx)
{
    decContext      save = *ctx;
    decNumber      *z;

    ctx->digits = max(a->digits, b->digits) + 1;
    z = decNumberAlloc(ctx->digits);
    decNumberSubtract(z, a, b, ctx);

    *ctx = save;

    return z;
}



decNumber      *
decNumberMultiplyAlloc(decNumber * a, decNumber * b, decContext * ctx)
{
    decContext      save = *ctx;
    decNumber      *z;

    ctx->digits = a->digits + b->digits;
    z = decNumberAlloc(ctx->digits);
    decNumberMultiply(z, a, b, ctx);

    *ctx = save;

    return z;
}



decNumber      *
decNumberModuloAlloc(decNumber * a, decNumber * b, decContext * ctx)
{

    decContext      save = *ctx;
    decNumber      *z;

    ctx->digits = a->digits;
    z = decNumberAlloc(ctx->digits);
    decNumberRemainder(z, a, b, ctx);

    *ctx = save;

    return z;
}

decNumber      *
decNumberDivideIntegerAlloc(decNumber * a, decNumber * b, decContext * ctx)
{

    decContext      save = *ctx;
    decNumber      *z;


    ctx->digits = a->digits;
    z = decNumberAlloc(ctx->digits);
    decNumberDivideInteger(z, a, b, ctx);

    *ctx = save;

    return z;
}




decNumber      *
decNumberFactorial(int n, decContext * ctx)
{

    decNumber      *z,
                    f,
                   *one;
    decContext      save;

    one = decNumberAlloc(1);
    decNumberFromString(one, "1", ctx);

    if (n <= 1)
	return one;

    save = *ctx;
    ctx->digits = (int) (log10((double) n) * n);
    z = decNumberAlloc(ctx->digits);
    decNumberCopy(z, one);
    decNumberCopy(&f, one);

    for (; n--;) {
	decNumberMultiply(z, z, &f, ctx);
	decNumberAdd(&f, &f, one, &save);
    }

    free(one);
    *ctx = save;

    return z;
}


decNumber      *
decNumberPowInteger(decNumber * x, decNumber * y, decContext * ctx)
{
    // TODO: check power of 2 bases
    // ==> 2**3 gives 0 !!!

    decContext      save = *ctx;
    decNumber      *z,
                   *s,
                   *t,
                   *u,
                   *ONE,
                   *TWO;
    int             minus;

    if ((minus = decNumberIsNegative(y)))
	decNumberMinus(y, y, ctx);

    ONE = decNumberAllocAssignConst("1", ctx);
    TWO = decNumberAllocAssignConst("2", ctx);


    s = decNumberAllocAssign(ONE);
    t = decNumberAllocAssign(x);
    u = decNumberAllocAssign(y);


    while (!decNumberIsZero(u)) {	// while (u != 0)

	if (decNumberIsOdd(u)) {
	    z = decNumberMultiplyAlloc(s, t, ctx);
	    free(s);
	    s = z;
	}

	decNumberDivideInteger(u, u, TWO, ctx);
	z = decNumberMultiplyAlloc(t, t, ctx);
	free(t);
	t = z;

    }


    if (minus) {
	ctx->digits = min(s->digits, ctx->digits);
	decNumberDivide(s, ONE, s, ctx);
    }

    free4(t, u, ONE, TWO);
    *ctx = save;

    return s;

}


decNumber      *
decNumberGCD(decNumber * _a, decNumber * _b, decContext * ctx)
{

    decNumber      *a,
                   *b,
                   *c;

    b = decNumberAllocAssign(_b);
    a = decNumberAllocAssign(_a);

    while (!decNumberIsZero(b)) {
	c = decNumberModuloAlloc(a, b, ctx);
	a = decNumberSaveCopy(a, b);
	b = decNumberSaveCopy(b, c);
	free(c);
    }

    free(b);
    return a;
}

void
decNumberPrint(decNumber * num)
{
    char           *s = (char *) malloc(num->digits + 10);

    decNumberToString(num, s);
    printf("%s ", s);
    free(s);
}

void
decNumberPrintLn(decNumber * num)
{
    decNumberPrint(num);
    printf("\n");
}

void
decNumberLabelPrint(const char *txt, decNumber * num)
{
    printf("%s ", txt);
    decNumberPrint(num);
}

void
decNumberLabelPrintLn(const char *txt, decNumber * num)
{
    decNumberLabelPrint(txt, num);
    printf("\n");
}

#ifndef PC
void
decNumberPushString(decNumber *num)
{
    char		*s = (char *) sys_chkptr(malloc(num->digits+10));
    
    decNumberToString(num,s);
    sat_stack_push_string(s);
    free(s);
}
#endif

    

// Globals

decNumber      *k1,
               *k2,
               *k3,
               *k4,
               *k5,
               *k6,
               *K;

decNumber * P(int n, decContext * ctx)
{
    decNumber      *f,
                   *dn,
                   *z,
                   *r,
                   *r1;

    f = decNumberFactorial(6 * n, ctx);
    dn = decNumberFromInteger(n, ctx);
    z = decNumberMultiplyAlloc(dn, k1, ctx);
    r1 = decNumberAddAlloc(k2, z, ctx);

    r = decNumberMultiplyAlloc(r1, f, ctx);
    free4(f, dn, z, r1);

    return r;
}


decNumber * Q(int n, decContext * ctx)
{
    decNumber      *f,
                   *three,
                   *fp3,
                   *f3,
                   *dn,
                   *kn,
                   *r;

    f = decNumberFactorial(n, ctx);
    three = decNumberAllocAssignConst("3", ctx);
    if (n == 2)			// CHEAT!
	fp3 = decNumberAllocAssignConst("8", ctx);
    else
	fp3 = decNumberPowInteger(f, three, ctx);

    // fp3 = fac(n)**3

    f3 = decNumberFactorial(3 * n, ctx);
    free(f);
    f = decNumberMultiplyAlloc(fp3, f3, ctx);
    // f = fac(n)**3 * fac(3*n)

    dn = decNumberFromInteger(n, ctx);
    kn = decNumberPowInteger(K, dn, ctx);

    r = decNumberMultiplyAlloc(f, kn, ctx);

    free6(f, three, fp3, f3, dn, kn);

    return r;
}


int
#ifdef PC
main(int argc, char **argv)
#else
main()
#endif
{
    int             i,
                    n;

    decNumber      *eight,
                   *z,
                   *p0,
                   *p,
                   *q0,
                   *q,
                   *g1,
                   *t1,
                   *t2,
                   *pi;
    decContext      set;

#ifdef PC

    {
	int             value;

	signal(SIGFPE, signalHandler);	// set up signal handler
	value = setjmp(preserve);	// preserve and test environment

	if (value) {		// (non-0 after longjmp)
	    set.status &= DEC_Errors;	// keep only errors
	    printf("\nSignal trapped [%s].\n",
		   decContextStatusToString(&set));
	    return 1;
	}
    }

#else
    sys_slowOff();
    clear_screen();
    
#endif

    decContextDefault(&set, DEC_INIT_BASE);	// initialize

#ifndef PC
    set.traps = 0;
#endif

    // set.traps=0; // no traps, thank you
    set.digits = DECNUMDIGITS;

    k1 = decNumberAllocAssignConst("545140134", &set);
    k2 = decNumberAllocAssignConst("13591409", &set);
    k3 = decNumberAllocAssignConst("640320", &set);
    k4 = decNumberAllocAssignConst("100100025", &set);
    k5 = decNumberAllocAssignConst("327843840", &set);
    k6 = decNumberAllocAssignConst("53360", &set);

    eight = decNumberAllocAssignConst("8", &set);
    z = decNumberMultiplyAlloc(k4, k5, &set);

    K = decNumberMultiplyAlloc(eight, z, &set);
    free(z);

#ifdef PC
    n = argc > 1 ? atoi(*++argv) : 10;
#else
    n = sat_stack_depth()? (int) sat_pop_real() : 10;
    printf("Chudnovsky pi iteration [%d]\n\n",n);
#endif

    p0 = P(0, &set);
    q0 = Q(0, &set);



    for (i = 1; i <= n; i++) {

	printf(".");
	
	p = P(i, &set);
	q = Q(i, &set);

	if (i & 1)
	    decNumberMinus(p, p, &set);	// p = -p


	g1 = decNumberDivideIntegerAlloc(q, q0, &set);
	t1 = decNumberMultiplyAlloc(p0, g1, &set);
	z = decNumberAddAlloc(t1, p, &set);
	free2(p0, t1);
	p0 = z;


	z = decNumberMultiplyAlloc(g1, q0, &set);
	free(q0);

	q0 = z;

	free3(p, q, g1);
    }



    set.digits = p0->digits / 2;
    t1 = decNumberAlloc(set.digits);
    decNumberSquareRoot(t1, k3, &set);


    t2 = decNumberMultiplyAlloc(k6, t1, &set);

    free(t1);
    t1 = decNumberMultiplyAlloc(t2, q0, &set);

    free2(t2,q0);
    
    pi = decNumberAlloc(set.digits);
    
    decNumberDivide(pi, t1, p0, &set);
    
    free2(t1,p0);
    
#ifdef PC
    decNumberPrintLn(pi);
#else

    decNumberPushString(pi);
    //sys_slowOn();
    //WAIT_CANCEL;
#endif

    return 0;
}
