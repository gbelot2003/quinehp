/* ------------------------------------------------------------------ */
/* Decimal Number Library Demonstration program                       */
/* ------------------------------------------------------------------ */
/* Copyright (c) Ingo Blank 2006  All rights reserved.                */
/* ----------------------------------------------------------------+- */
/*                                                 right margin -->|  */

// sqrt2.c 
// Calculate square root of two to arbitrary precision.

// $Id: sqrt2.c 317 2006-10-28 15:20:48Z ingo $

#define HP49 1

#define DECNUMDIGITS 40

#ifdef HP49
#include <hpgcc49.h>
#else
#include <stdio.h>                 // for printf
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <signal.h>                // signal handling
#include <setjmp.h>                // setjmp/longjmp
#endif

#include "decNumber.h"

#ifndef max
#define max(a,b) (a) > (b) ? (a) : (b)
#endif

#ifndef min
#define min(a,b) (a) < (b) ? (a) : (b)
#endif

typedef struct {
    int32_t digits;
    int32_t exponent;
    uint8_t bits;
} decNumberPrologue;

#define decNumberSize(digits) (sizeof(decNumberPrologue) + ((digits)+DECDPUN-1)/DECDPUN * sizeof(decNumberUnit))

decNumber *
decNumberAlloc(int digits)
{
    return (decNumber *) malloc(decNumberSize(digits));
}


void 
decNumberPrint(decNumber *d)
{
    char *s = (char *) malloc(d->digits+10);
    
    decNumberToString(d,s);
#ifdef HP49
    sat_stack_push_string(s);
#else
    printf("%s ",s);
#endif
    free(s);
}


int
#ifdef HP49
main()
#else
main(int argc, char **argv)
#endif
{
    decNumber *number,two;
    decContext set;

    #define DEF_SQRT2_DIGITS 50
    
#ifdef HP49
    int sqrt2_digits = sat_stack_depth() ? (int) sat_pop_real() : DEF_SQRT2_DIGITS;
	#else
    int sqrt2_digits = argc > 1 ? atoi(*++argv) : DEF_SQRT2_DIGITS;
#endif
    
	
	
	
    decContextDefault(&set,DEC_INIT_BASE);
    set.traps = 0;
    set.digits = DECNUMDIGITS;
    
    decNumberFromString(&two,"2",&set);
        
    number = decNumberAlloc(sqrt2_digits);
    set.digits = sqrt2_digits;
	
	
    decNumberSquareRoot(number,&two,&set);
    decNumberPrint(number);
    
    free(number);
    
    return 0;
}
