/* ------------------------------------------------------------------ */
/* Decimal Number Library Demonstration program                       */
/* ------------------------------------------------------------------ */
/* Copyright (c) Ingo Blank 2006  All rights reserved.                */
/* ----------------------------------------------------------------+- */
/*                                                 right margin -->|  */

// matrix.c 
// Simple matrix demo, providing some fundamental support
// functions.

// $Id: matrix.c 319 2006-10-29 02:54:35Z ingo $


#define  DECNUMDIGITS 30 // change if appropriate ...

#include "decNumber.h"

#ifdef PC
#include <stdio.h>
#include <stdlib.h>
#else
#define TINY_PRINTF 1
#include <hpgcc49.h>
#endif

#ifdef __GNUC__
#define INLINE inline
#else
#define INLINE __inline
#endif

typedef struct {
     int32_t digits;
     int32_t exponent;
     uint8_t bits;

} decNumberPrologue;

#define decNumberSize(digits) (sizeof(decNumberPrologue) +((digits)+DECDPUN-1)/DECDPUN * sizeof(decNumberUnit))

INLINE decNumber *
decNumberAlloc (size_t digits)
{
     return (decNumber *) malloc(decNumberSize(digits));

}

decNumber *
decNumberAllocAssign(decNumber *rhs)
{
     decNumber *lhs;

     lhs = decNumberAlloc(rhs->digits);
     return decNumberCopy(lhs,rhs);

}

void
decNumberPrint(decNumber *d)
{
     char *s = (char *) malloc(2*d->digits+20);

     decNumberToString(d,s);
     printf("%s ",s);
     free(s);

}

decNumber ***
decNumberReadMatrix(int m, int n, decContext *ctx)
{
     // Dynamically allocate an n x m Matrix of decNumber elements
     // CAUTION: Memory allocation validation left out ...

        int i,j;
        decNumber ***mat;
        decNumber ONE,x;

        decNumberFromString(&ONE,"1",ctx);
        decNumberCopy(&x,&ONE);

     // Allocate m row vectors

        mat = (decNumber ***) calloc(m,sizeof(decNumber ***));
        // Pointer check !

     // Allocate the column vectors for each row

        for (i = 0; i < m; i++)
                mat[i] = (decNumber **) calloc(n,sizeof(decNumber **));
                // Pointer check!

     // Finally allocate m x n decNumber elements

        for (i = 0; i < m; i++) {
                for(j = 0; j < n; j++) {
             // AllocAssign just as a sample, replace with your own code
                        mat[i][j] = decNumberAllocAssign(&x);
                        // Pointer check!

             // increment sample value ...
                        decNumberAdd(&x,&x,&ONE,ctx);

                }

        }

     // return the matrix

        return mat;

}

void
decNumberPrintMatrix(decNumber ***mat, int rows, int cols)
{
        int i,j;

        for(i = 0; i < rows; i++) {
                for( j = 0; j < cols; j++)
                        decNumberPrint(mat[i][j]);
                printf("\n");
        }

}

void
decNumberFreeMatrix(decNumber ***mat, int rows, int cols)
{
        int i,j;

        // Free each single element ...

        for (i = 0; i < rows; i++)
                for(j = 0; j < cols; j++)
                        free(mat[i][j]);

        // ... then each row vector ...

        for(i = 0; i < rows; i++)
                free(mat[i]);

        // ... and finally the 'root'

        free(mat);

}

int
main()
{
     // Test run ...

     int rows, cols;
     decNumber ***mat;
     decContext set;
    
#ifndef PC
    sys_slowOff();
    clear_screen();
#endif

     decContextDefault(&set, DEC_INIT_BASE); // initialize
     set.traps=0;                     // no traps, thank you
     set.digits=DECNUMDIGITS;         // set precision

     rows = cols = 5;
     mat = decNumberReadMatrix(rows,cols,&set);
     decNumberPrintMatrix(mat,rows,cols);
     decNumberFreeMatrix(mat,rows,cols);

#ifndef PC
    sys_slowOn();
    WAIT_CANCEL ;
#endif

     return 0;

} 
