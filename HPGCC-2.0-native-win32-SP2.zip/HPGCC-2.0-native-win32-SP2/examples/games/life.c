#include <hpgcc49.h>
#include <hpgraphics.h>

#define HEIGHT 80
#define WIDTH 128


char count[HEIGHT*WIDTH];
char state[HEIGHT*WIDTH];
char newcount[HEIGHT*WIDTH];


// UPDATE LIFE COUNT FOR NEIGHBORS

void add_neighbors(int j,int i,int value)
{
int offset0;
int leftadd,rightadd,topadd,botadd;

if(i==0) leftadd=WIDTH-1; else leftadd=-1;
if(i==WIDTH-1) rightadd=-WIDTH+1; else rightadd=1;
if(j==0) topadd=(HEIGHT-1)*WIDTH; else topadd=-WIDTH;
if(j==HEIGHT-1) botadd=-(HEIGHT-1)*WIDTH; else botadd=WIDTH;


offset0=j*WIDTH+i;

// TOP-LEFT
newcount[offset0+topadd+leftadd]+=value;
// TOP
newcount[offset0+topadd]+=value;
// TOP-RIGHT
newcount[offset0+topadd+rightadd]+=value;
// LEFT
newcount[offset0+leftadd]+=value;
// RIGHT
newcount[offset0+rightadd]+=value;
// BOT-LEFT
newcount[offset0+botadd+leftadd]+=value;
// BOT
newcount[offset0+botadd]+=value;
// BOT-RIGHT
newcount[offset0+botadd+rightadd]+=value;


}


// DETERMINE NEW STATE AFTER ONE TICK

void play_tick()
{
int i,j;
int offset;
// COPY COUNT TO TEMPORARY STORAGE
memmove(newcount,count,sizeof(char)*HEIGHT*WIDTH);

offset=0;

for(j=0;j<HEIGHT;++j)
{
for(i=0;i<WIDTH;++i)
{
if(state[offset]) {
// IF ALIVE, CHECK IF IT SHOULD DIE
if( (count[offset]|1)!=3 ) {
// KILL IT
state[offset]=0;
hpg_set_color(hpg_stdscreen,HPG_COLOR_WHITE);
hpg_draw_pixel(i,j);
// UPDATE COUNT FOR ALL NEIGHBORS
add_neighbors(j,i,-1);

}

}
else {
// IF DEAD, CHECK IF IT SHOULD COME TO LIFE
if(count[offset]==3) {
state[offset]=1;
hpg_set_color(hpg_stdscreen,HPG_COLOR_BLACK);
hpg_draw_pixel(i,j);
// UPDATE NEIGHBORS COUNT
add_neighbors(j,i,1);
}
}
++offset;
}
}

// MOVE BACK TO PERMANENT STORAGE
memmove(count,newcount,sizeof(char)*WIDTH*HEIGHT);

}

// SET INITIAL STATE
void calc_count()
{
int i,j;
int offset;
// COPY COUNT TO TEMPORARY STORAGE
memset((void *)newcount,0,sizeof(char)*HEIGHT*WIDTH);

offset=0;

for(j=0;j<HEIGHT;++j)
{
for(i=0;i<WIDTH;++i)
{
if(state[offset]) { add_neighbors(j,i,1); hpg_set_color(hpg_stdscreen,HPG_COLOR_BLACK); hpg_draw_pixel(i,j); }
else { hpg_set_color(hpg_stdscreen,HPG_COLOR_WHITE); hpg_draw_pixel(i,j); } 
++offset;
}
}

// MOVE BACK TO PERMANENT STORAGE
memmove(count,newcount,sizeof(char)*WIDTH*HEIGHT);

}



int main()
{

hpg_clear();

// SET TO RANDOM STATE
hpg_draw_text("Hello Conway",20,30);

// GET STATE MATRIX

int i,j,offset;
offset=0;
for(j=0;j<HEIGHT;++j)
{
for(i=0;i<WIDTH;++i)
{
if(hpg_get_pixel(hpg_stdscreen,i,j)) state[offset]=1;
else state[offset]=0;
++offset;
}
}


// INITIATE CONWAY'S ITERATOR
calc_count();

while(!keyb_isON())
{
play_tick();
}
return 0;
}

