#define TINY_PRINTF 1
#include <hpgcc49.h>

int f(int x)
{
    return(x+10);
}

int g(int (*func)(int), int x)
{
    return(func(x)-10);
}


int main(void)
{

    clear_screen();

    printf("d0:%d\n",g(f,5));

    WAIT_CANCEL;
    return 0;
}






