#define TINY_PRINTF 1
#include <hpgcc49.h>

int
main()
{
    
    int yy,mm,dd,HH,MM,SS;
    char *nss,*ns[3] = {"st","nd","rd"};
    char *mn[12] = {"January","February","March","April","May","June","July","August",
                    "September","October","November","December"};
                    
    clear_screen();
    
    sscanf(isotime(NULL),"%d-%d-%d %d:%d:%d",&yy,&mm,&dd,&HH,&MM,&SS);
    nss =  dd < 4 ? ns[dd-1] : "th";
    int h = (h = HH % 12) ? h : 12;
    
    printf("%s the %d%s %d, %d:%02d %cm\n",mn[mm-1],dd,nss,yy,h,MM,HH < 12 ? 'a' : 'p');
    
    WAIT_CANCEL;
    
    return 0;
}
