#ifndef __LOCAL_INCLUDES_H
#define __LOCAL_INCLUDES_H

#include "oldnames.h"
#include <hpgcc49.h>

#endif // __LOCAL_INCLUDES_H
