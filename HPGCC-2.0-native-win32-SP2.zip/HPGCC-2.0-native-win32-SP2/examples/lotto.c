/*
    lotto.c
    
    Draw N out of K ( 6 ; 49 ) numbers
    Simple program demonstrating the use of bitvectors as sets.
    
    ibl
    2005-08-21
*/

typedef unsigned char uint8;

#ifdef PC
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#ifdef __GNUC__
#define LONGLONG long long
#define ULONGLONG unsigned long long
#else
#define LONGLONG __int64
#define ULONGLONG unsigned __int64
#endif
#define WAIT_CANCEL
#define ARGS 1
#else
#define TINY_PRINTF 1
#include <hpgcc49.h>
#define ARGS 0
#endif


#ifdef PC

// Use LUT bitcount caching for possibly large amounts of data ...

int
_bitcount8(uint8 b)
{
    if (b)
        return _bitcount8(b >> 1) + (b & 1);
    return 0;
}

int
bitcount8(uint8 b)
{
    static uint8 bc_lut[256];
    
    if(!bc_lut[1]) {
        int i;
        for(i = 0; i < 256; i++)
            bc_lut[i] = _bitcount8((uint8) i);
    }
        
    return bc_lut[b];
}

int
bit_count(ULONGLONG b)
{
    int i,c;
    
    for ( i = c = 0; i < sizeof(b); i++ ) {
        c += bitcount8((uint8)(b & 0xFF));
        b >>= 8;
    }
    
    return c;
}

#else

// ... use straightforward recursive bitcount.

int
bit_count(ULONGLONG b)
{
    if(b)
        return bit_count(b >> 1) + (b & 1);
    return 0;
}

#endif


void
draw_and_print()
{
    #define N 6
    #define K 49
    
    ULONGLONG bits = 0LL;
    int z;
    
    // Draw N out of K  numbers ...
   
    while (bit_count(bits) != N) 
        bits |= (1ULL << (rand() % K));
    
    // ... and display them
   
    for (z=1; bits;) 
        
        if (bits & 1) {
            printf("%2d ",z);
            bits >>= 1;
            z++; 
           
        }
        else 
            do {
                bits >>= 1;
                z++;
            } while(!(bits & 1));
            
            
    printf("\n");
}
    

int
main(
#ifdef PC
        int argc, char *argv[]
#endif
)

{
   int d;
    
#ifdef PC
    srand(time(0));
#else
    char **argv;
    clear_screen();
	srand(sys_RTC_seconds());
    int argc = sat_stack_pop_stdargs(&argv);
#endif
    
    printf("Here are your Lotto numbers:\n\n");
    
    if (argc > ARGS) 
        d = atoi(argv[ARGS]);
    else
        d = 1;
    
    for(;d--;)
        draw_and_print();
    
    printf("\nGood luck!\n");
    
    WAIT_CANCEL;
    
	return 0;
}

